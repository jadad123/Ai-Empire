from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.config import settings
from app.api.routes import sites, sources, articles, dashboard
from app.models.base import engine, Base


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Shutdown
    await engine.dispose()


app = FastAPI(
    title="Global AI Content Empire",
    description="Centralized automation platform for managing niche websites",
    version="1.0.0",
    lifespan=lifespan
)

# CORS
origins = settings.allowed_origins.split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard"])
app.include_router(sites.router, prefix="/api/sites", tags=["Sites"])
app.include_router(sources.router, prefix="/api/sources", tags=["Sources"])
app.include_router(articles.router, prefix="/api/articles", tags=["Articles"])


@app.get("/")
async def root():
    return {"message": "Global AI Content Empire API", "status": "running"}


@app.get("/health")
async def health():
    return {"status": "healthy"}
